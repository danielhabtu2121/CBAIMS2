package com.bank.cims.controller;

import com.bank.cims.model.*;
import com.bank.cims.repository.*;
import com.bank.cims.service.CimsService;
import com.bank.cims.service.WorkflowAuthorizationService;
import com.bank.cims.service.RoleHierarchyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/workflow")
@CrossOrigin(origins = "*")
public class WorkflowController {

    @Autowired
    private WorkflowTaskRepository workflowTaskRepository;

    @Autowired
    private ApprovalHistoryRepository approvalHistoryRepository;

    @Autowired
    private DelegationRepository delegationRepository;

    @Autowired
    private CimsService cimsService;

    @Autowired
    private WorkflowAuthorizationService workflowAuthorizationService;

    @Autowired
    private RoleHierarchyService roleHierarchyService;

    @GetMapping("/tasks")
    public ResponseEntity<List<WorkflowTask>> getTasks(
            @RequestParam(required = false) String role,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String makerId) {
        // Return only tasks relevant to the current workflow inbox.
        // A checker gets pending tasks assigned to their role or hierarchical jurisdiction (excluding their own maker submissions per Four-Eyes Principle and Level 1 tasks they already approved).
        // A maker also gets their own submissions matching the effective status.
        LinkedHashMap<String, WorkflowTask> result = new LinkedHashMap<>();
        String effectiveStatus = (status == null || status.isBlank()) ? "Pending" : status;

        if (role != null && !role.isBlank()) {
            List<WorkflowTask> allTasks = workflowTaskRepository.findAll();
            for (WorkflowTask t : allTasks) {
                if ("ALL".equalsIgnoreCase(effectiveStatus) || effectiveStatus.equalsIgnoreCase(t.getStatus())) {
                    boolean roleMatch = role.equalsIgnoreCase(t.getCandidateRole())
                            || roleHierarchyService.isAuthorizedToActOn(role, t.getCandidateRole())
                            || "ADMIN".equalsIgnoreCase(role) || "SYSADMIN".equalsIgnoreCase(role);
                    if (roleMatch) {
                        // Four-Eyes check for checker inbox: if querying pending approvals, exclude maker's own submissions
                        if ("Pending".equalsIgnoreCase(effectiveStatus) && makerId != null && !makerId.isBlank() && isSamePerson(t.getMakerId(), makerId)) {
                            continue;
                        }
                        // Multi-level hierarchy check: if task is in Level 2 Review, exclude users who already approved Level 1
                        if ("Level 2 Review".equalsIgnoreCase(t.getCurrentStep()) && makerId != null && !makerId.isBlank()) {
                            List<ApprovalHistory> histories = approvalHistoryRepository.findByWorkflowTaskIdOrderByDecidedAtDesc(t.getId());
                            boolean alreadyApprovedLevel1 = histories.stream().anyMatch(h ->
                                    "Approved".equalsIgnoreCase(h.getDecision()) && isSamePerson(h.getActorId(), makerId));
                            if (alreadyApprovedLevel1) {
                                continue;
                            }
                        }
                        result.put(t.getId(), t);
                    }
                }
            }
        } else if (status != null && !status.isBlank()) {
            for (WorkflowTask t : workflowTaskRepository.findByStatus(status)) result.put(t.getId(), t);
        }

        if (makerId != null && !makerId.isBlank()) {
            for (WorkflowTask t : workflowTaskRepository.findByMakerIdIgnoreCase(makerId)) {
                if ("ALL".equalsIgnoreCase(effectiveStatus) || effectiveStatus.equalsIgnoreCase(t.getStatus())) {
                    result.put(t.getId(), t);
                }
            }
        }

        if (role == null && (status == null || status.isBlank()) && (makerId == null || makerId.isBlank())) {
            return ResponseEntity.ok(workflowTaskRepository.findAll());
        }
        return ResponseEntity.ok(new java.util.ArrayList<>(result.values()));
    }

    private boolean isSamePerson(String id1, String id2) {
        if (id1 == null || id2 == null) return false;
        String a = id1.trim().toLowerCase().replace("_user", "");
        String b = id2.trim().toLowerCase().replace("_user", "");
        return a.equals(b);
    }

    @PostMapping("/tasks/{taskId}/approve")
    public ResponseEntity<Map<String, Object>> approveTask(
            @PathVariable String taskId,
            @RequestParam String userId,
            @RequestParam(required = false) String role,
            @RequestParam(required = false, defaultValue = "Approved by checker") String comments) {
        if (userId == null || userId.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "userId is required to approve a task."));
        }
        if (comments == null || comments.trim().isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "Approval comments cannot be blank."));
        }
        try {
            User authorized = workflowAuthorizationService.assertCanApprove(userId, taskId);
            cimsService.approveWorkflowTask(taskId, authorized.getUsername(), authorized.getRole(), comments.trim());
            return ResponseEntity.ok(Map.of("success", true, "message", "Task " + taskId + " approved."));
        } catch (RuntimeException e) {
            return ResponseEntity.status(409).body(Map.of("success", false, "error", e.getMessage() == null ? "Workflow action failed." : e.getMessage()));
        }
    }

    @PostMapping("/tasks/{taskId}/reject")
    public ResponseEntity<Map<String, Object>> rejectTask(
            @PathVariable String taskId,
            @RequestParam String userId,
            @RequestParam(required = false) String role,
            @RequestParam String comments) {
        if (userId == null || userId.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "userId is required to reject a task."));
        }
        if (comments == null || comments.trim().isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "Mandatory rejection reason/comments required."));
        }
        try {
            User authorized = workflowAuthorizationService.assertCanApprove(userId, taskId);
            cimsService.rejectWorkflowTask(taskId, authorized.getUsername(), authorized.getRole(), comments.trim());
            return ResponseEntity.ok(Map.of("success", true, "message", "Task " + taskId + " rejected."));
        } catch (RuntimeException e) {
            return ResponseEntity.status(409).body(Map.of("success", false, "error", e.getMessage() == null ? "Workflow action failed." : e.getMessage()));
        }
    }

    @PostMapping("/tasks/{taskId}/return")
    public ResponseEntity<Map<String, Object>> returnTask(
            @PathVariable String taskId,
            @RequestParam String userId,
            @RequestParam(required = false) String role,
            @RequestParam String correctionNote) {
        if (userId == null || userId.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "userId is required to return a task."));
        }
        if (correctionNote == null || correctionNote.trim().isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "Mandatory return/correction notes required."));
        }
        try {
            User authorized = workflowAuthorizationService.assertCanApprove(userId, taskId);
            cimsService.returnWorkflowTask(taskId, authorized.getUsername(), authorized.getRole(), correctionNote.trim());
            return ResponseEntity.ok(Map.of("success", true, "message", "Task " + taskId + " returned to maker for correction."));
        } catch (RuntimeException e) {
            return ResponseEntity.status(409).body(Map.of("success", false, "error", e.getMessage() == null ? "Workflow action failed." : e.getMessage()));
        }
    }

    @PostMapping("/tasks/{taskId}/resubmit")
    public ResponseEntity<Map<String, Object>> resubmitTask(
            @PathVariable String taskId,
            @RequestParam String userId) {
        if (userId == null || userId.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "userId is required to resubmit a task."));
        }
        try {
            cimsService.resubmitReturnedWorkflowTask(taskId, userId);
            return ResponseEntity.ok(Map.of("success", true, "message", "Task resubmitted to the configured checker."));
        } catch (RuntimeException e) {
            return ResponseEntity.status(400).body(Map.of("success", false, "error", e.getMessage()));
        }
    }

    @PostMapping("/bulk-approve")
    public ResponseEntity<Map<String, Object>> bulkApprove(
            @RequestBody List<String> taskIds,
            @RequestParam String userId,
            @RequestParam(required = false) String role,
            @RequestParam(required = false, defaultValue = "Bulk approved by checker") String comments) {
        if (userId == null || userId.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "userId is required to bulk approve."));
        }
        if (comments == null || comments.trim().isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "A valid approval comment is required for bulk authorization."));
        }
        int approved = 0;
        List<String> failures = new java.util.ArrayList<>();
        for (String id : taskIds) {
            try {
                User authorized = workflowAuthorizationService.assertCanApprove(userId, id);
                cimsService.approveWorkflowTask(id, authorized.getUsername(), authorized.getRole(), comments);
                approved++;
            } catch (RuntimeException e) {
                failures.add(id + ": " + (e.getMessage() == null ? "approval failed" : e.getMessage()));
            }
        }
        boolean success = failures.isEmpty();
        Map<String,Object> result = new LinkedHashMap<>();
        result.put("success", success);
        result.put("approvedCount", approved);
        result.put("failedCount", failures.size());
        result.put("failures", failures);
        return ResponseEntity.status(success ? 200 : 409).body(result);
    }

    @GetMapping("/tasks/{taskId}/history")
    public ResponseEntity<List<ApprovalHistory>> getTaskHistory(@PathVariable String taskId) {
        return ResponseEntity.ok(approvalHistoryRepository.findByWorkflowTaskIdOrderByDecidedAtDesc(taskId));
    }

    // --- Delegations ---
    @GetMapping("/delegations")
    public ResponseEntity<List<Delegation>> getDelegations() {
        return ResponseEntity.ok(delegationRepository.findAll());
    }

    @PostMapping("/delegations")
    public ResponseEntity<Delegation> createDelegation(@RequestBody Delegation delegation) {
        if (delegation.getId() == null || delegation.getId().isBlank()) {
            delegation.setId("del-" + UUID.randomUUID().toString().substring(0, 8));
        }
        delegation.setStatus("Active");
        return ResponseEntity.ok(delegationRepository.save(delegation));
    }

    @PostMapping("/delegations/{id}/revoke")
    public ResponseEntity<Map<String, Object>> revokeDelegation(@PathVariable String id) {
        delegationRepository.findById(id).ifPresent(d -> {
            d.setStatus("Revoked");
            delegationRepository.save(d);
        });
        return ResponseEntity.ok(Map.of("success", true, "message", "Delegation revoked."));
    }
}
