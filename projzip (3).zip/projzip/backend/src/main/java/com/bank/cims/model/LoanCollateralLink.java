package com.bank.cims.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "cims_loan_collateral_links")
public class LoanCollateralLink {
    @Id
    private String id;

    @Column(name = "loan_account_id", nullable = false)
    private String loanAccountId;

    @Column(name = "facility_id")
    private String facilityId;

    @Column(name = "account_number")
    private String accountNumber;

    @Column(name = "branch_code")
    private String branchCode;

    @Column(name = "linked_reference_no")
    private String linkedReferenceNo;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(name = "linkage_currency")
    private String linkageCurrency = "ETB";

    @Column(name = "overall_amount")
    private double overallAmount;

    @Column(name = "collateral_category")
    private String collateralCategory;

    private double haircut = 0;

    @Column(name = "limit_amount")
    private double limitAmount;

    @Column(name = "linked_amount")
    private double linkedAmount;

    @Column(name = "linked_percent")
    private double linkedPercent;

    @Column(name = "util_order")
    private int utilOrder = 1;

    @Column(name = "reinstate_order")
    private int reinstateOrder = 1;

    @Column(name = "util_amount")
    private double utilAmount;

    private String status = "Active";

    @Column(name = "taken_over")
    private String takenOver = "N";

    @Column(name = "effective_date")
    private String effectiveDate;

    @Column(name = "end_date")
    private String endDate;

    @Column(name = "change_reason", columnDefinition = "TEXT")
    private String changeReason;

    @Column(name = "collateral_id", nullable = false)
    private String collateralId;

    @Column(name = "allocated_amount", nullable = false)
    private double allocatedAmount;

    @Column(name = "linkage_type")
    private String linkageType = "Primary";

    @Column(name = "customer_id")
    private String customerId;

    @Column(name = "relationship_status")
    private String relationshipStatus = "Active";

    @Column(name = "release_status")
    private String releaseStatus = "Eligible";

    @Column(name = "utilization_pct")
    private double utilizationPct = 0;

    @Column(name = "maker_id")
    private String makerId;

    @Column(name = "maker_dt_stamp")
    private String makerDtStamp = LocalDateTime.now().toString();

    @Column(name = "checker_id")
    private String checkerId;

    @Column(name = "checker_dt_stamp")
    private String checkerDtStamp;

    @Column(name = "record_stat")
    private String recordStat = "O";

    @Column(name = "auth_stat")
    private String authStat = "A";

    @Column(name = "mod_no")
    private int modNo = 1;

    private String source = "CBS_SIM";

    @Column(name = "source_record_id")
    private String sourceRecordId;

    @Column(name = "cbs_sync_status")
    private String cbsSyncStatus = "Synced";

    @Column(name = "cbs_synced_at")
    private String cbsSyncedAt;

    @Column(name = "cbs_facility_ref")
    private String cbsFacilityRef;

    @Column(name = "cbs_loan_account")
    private String cbsLoanAccount;

    @Column(name = "cbs_collateral_ref")
    private String cbsCollateralRef;

    @Column(name = "facility_coverage_pct")
    private double facilityCoveragePct = 0;

    @Column(name = "collateral_allocation_pct")
    private double collateralAllocationPct = 0;

    @Column(name = "collateral_rank")
    private String collateralRank = "1st";

    @Column(name = "is_first_degree_internal")
    private boolean isFirstDegreeInternal = true;

    @Column(name = "first_degree_collateral_id")
    private String firstDegreeCollateralId;

    @Column(name = "first_degree_holder_name")
    private String firstDegreeHolderName = "Dashen Bank S.C.";

    @Column(name = "first_degree_facility_ref")
    private String firstDegreeFacilityRef;

    @Column(name = "first_degree_outstanding_balance")
    private double firstDegreeOutstandingBalance = 0.0;

    @Column(name = "first_degree_balance_as_of_date")
    private String firstDegreeBalanceAsOfDate;

    @Column(name = "registered_mortgage_amount")
    private double registeredMortgageAmount = 0.0;

    @Column(name = "mortgage_registration_number")
    private String mortgageRegistrationNumber;

    @Column(name = "mortgage_registration_date")
    private String mortgageRegistrationDate;

    @Column(name = "first_degree_policy_number")
    private String firstDegreePolicyNumber;

    @Column(name = "first_degree_insurer")
    private String firstDegreeInsurer;

    @Column(name = "first_degree_policy_expiry")
    private String firstDegreePolicyExpiry;

    @Column(name = "bank_noted_as_second_mortgagee")
    private boolean bankNotedAsSecondMortgagee = false;

    @Column(name = "first_degree_confirmation_doc_id")
    private String firstDegreeConfirmationDocId;

    @Column(name = "first_degree_extract_doc_id")
    private String firstDegreeExtractDocId;

    @Column(name = "borrower_customer_id")
    private String borrowerCustomerId;

    @Column(name = "legal_owner_customer_id")
    private String legalOwnerCustomerId;

    @Column(name = "legal_owner_name")
    private String legalOwnerName;

    @Column(name = "owner_without_cif")
    private boolean ownerWithoutCif = false;

    @Column(name = "relationship_context")
    private String relationshipContext = "Borrower-owned";

    @Column(name = "third_party")
    private boolean thirdParty = false;

    @Column(name = "relationship_to_borrower")
    private String relationshipToBorrower;

    @Column(name = "pledge_agreement_ref")
    private String pledgeAgreementRef;

    @Column(name = "consent_info", columnDefinition = "TEXT")
    private String consentInfo;

    @Column(name = "consent_document_ref")
    private String consentDocumentRef;

    public LoanCollateralLink() {}

    public LoanCollateralLink(String id, String loanAccountId, String collateralId, double allocatedAmount) {
        this.id = id;
        this.loanAccountId = loanAccountId;
        this.facilityId = loanAccountId;
        this.collateralId = collateralId;
        this.allocatedAmount = allocatedAmount;
        this.linkedAmount = allocatedAmount;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getLoanAccountId() { return loanAccountId; }
    public void setLoanAccountId(String loanAccountId) { this.loanAccountId = loanAccountId; }
    public String getFacilityId() { return facilityId; }
    public void setFacilityId(String facilityId) { this.facilityId = facilityId; }
    public String getAccountNumber() { return accountNumber; }
    public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }
    public String getBranchCode() { return branchCode; }
    public void setBranchCode(String branchCode) { this.branchCode = branchCode; }
    public String getLinkedReferenceNo() { return linkedReferenceNo; }
    public void setLinkedReferenceNo(String linkedReferenceNo) { this.linkedReferenceNo = linkedReferenceNo; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getLinkageCurrency() { return linkageCurrency; }
    public void setLinkageCurrency(String linkageCurrency) { this.linkageCurrency = linkageCurrency; }
    public double getOverallAmount() { return overallAmount; }
    public void setOverallAmount(double overallAmount) { this.overallAmount = overallAmount; }
    public String getCollateralCategory() { return collateralCategory; }
    public void setCollateralCategory(String collateralCategory) { this.collateralCategory = collateralCategory; }
    public double getHaircut() { return haircut; }
    public void setHaircut(double haircut) { this.haircut = haircut; }
    public double getLimitAmount() { return limitAmount; }
    public void setLimitAmount(double limitAmount) { this.limitAmount = limitAmount; }
    public double getLinkedAmount() { return linkedAmount; }
    public void setLinkedAmount(double linkedAmount) { this.linkedAmount = linkedAmount; }
    public double getLinkedPercent() { return linkedPercent; }
    public void setLinkedPercent(double linkedPercent) { this.linkedPercent = linkedPercent; }
    public int getUtilOrder() { return utilOrder; }
    public void setUtilOrder(int utilOrder) { this.utilOrder = utilOrder; }
    public int getReinstateOrder() { return reinstateOrder; }
    public void setReinstateOrder(int reinstateOrder) { this.reinstateOrder = reinstateOrder; }
    public double getUtilAmount() { return utilAmount; }
    public void setUtilAmount(double utilAmount) { this.utilAmount = utilAmount; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getTakenOver() { return takenOver; }
    public void setTakenOver(String takenOver) { this.takenOver = takenOver; }
    public String getEffectiveDate() { return effectiveDate; }
    public void setEffectiveDate(String effectiveDate) { this.effectiveDate = effectiveDate; }
    public String getEndDate() { return endDate; }
    public void setEndDate(String endDate) { this.endDate = endDate; }
    public String getChangeReason() { return changeReason; }
    public void setChangeReason(String changeReason) { this.changeReason = changeReason; }
    public String getCollateralId() { return collateralId; }
    public void setCollateralId(String collateralId) { this.collateralId = collateralId; }
    public double getAllocatedAmount() { return allocatedAmount; }
    public void setAllocatedAmount(double allocatedAmount) { 
        this.allocatedAmount = allocatedAmount; 
        this.linkedAmount = allocatedAmount;
    }
    public String getLinkageType() { return linkageType; }
    public void setLinkageType(String linkageType) { this.linkageType = linkageType; }

    public double getUtilizationPct() { return utilizationPct; }
    public void setUtilizationPct(double utilizationPct) { this.utilizationPct = utilizationPct; }
    public String getMakerId() { return makerId; }
    public void setMakerId(String makerId) { this.makerId = makerId; }
    public String getMakerDtStamp() { return makerDtStamp; }
    public void setMakerDtStamp(String makerDtStamp) { this.makerDtStamp = makerDtStamp; }
    public String getCheckerId() { return checkerId; }
    public void setCheckerId(String checkerId) { this.checkerId = checkerId; }
    public String getCheckerDtStamp() { return checkerDtStamp; }
    public void setCheckerDtStamp(String checkerDtStamp) { this.checkerDtStamp = checkerDtStamp; }
    public String getRecordStat() { return recordStat; }
    public void setRecordStat(String recordStat) { this.recordStat = recordStat; }
    public String getAuthStat() { return authStat; }
    public void setAuthStat(String authStat) { this.authStat = authStat; }
    public int getModNo() { return modNo; }
    public void setModNo(int modNo) { this.modNo = modNo; }
    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }
    public String getSourceRecordId() { return sourceRecordId; }
    public void setSourceRecordId(String sourceRecordId) { this.sourceRecordId = sourceRecordId; }
    public String getCbsSyncStatus() { return cbsSyncStatus; }
    public void setCbsSyncStatus(String cbsSyncStatus) { this.cbsSyncStatus = cbsSyncStatus; }
    public String getCbsSyncedAt() { return cbsSyncedAt; }
    public void setCbsSyncedAt(String cbsSyncedAt) { this.cbsSyncedAt = cbsSyncedAt; }
    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }
    public String getRelationshipStatus() { return relationshipStatus != null ? relationshipStatus : "Active"; }
    public void setRelationshipStatus(String relationshipStatus) { this.relationshipStatus = relationshipStatus; }
    public String getReleaseStatus() { return releaseStatus != null ? releaseStatus : "Eligible"; }
    public void setReleaseStatus(String releaseStatus) { this.releaseStatus = releaseStatus; }
    public double getLinkedPercentage() { return linkedPercent; }
    public void setLinkedPercentage(double linkedPercentage) { 
        this.linkedPercent = linkedPercentage; 
        this.collateralAllocationPct = linkedPercentage;
    }
    public double getUtilizationPercentage() { return utilizationPct; }
    public void setUtilizationPercentage(double utilizationPercentage) { this.utilizationPct = utilizationPercentage; }

    public String getCbsFacilityRef() { return cbsFacilityRef; }
    public void setCbsFacilityRef(String cbsFacilityRef) { this.cbsFacilityRef = cbsFacilityRef; }
    public String getCbsLoanAccount() { return cbsLoanAccount; }
    public void setCbsLoanAccount(String cbsLoanAccount) { this.cbsLoanAccount = cbsLoanAccount; }
    public String getCbsCollateralRef() { return cbsCollateralRef; }
    public void setCbsCollateralRef(String cbsCollateralRef) { this.cbsCollateralRef = cbsCollateralRef; }
    public double getFacilityCoveragePct() { return facilityCoveragePct; }
    public void setFacilityCoveragePct(double facilityCoveragePct) { this.facilityCoveragePct = facilityCoveragePct; }
    public double getCollateralAllocationPct() { return collateralAllocationPct > 0 ? collateralAllocationPct : linkedPercent; }
    public void setCollateralAllocationPct(double collateralAllocationPct) { 
        this.collateralAllocationPct = collateralAllocationPct; 
        this.linkedPercent = collateralAllocationPct;
    }

    public String getCollateralRank() { return collateralRank != null ? collateralRank : "1st"; }
    public void setCollateralRank(String collateralRank) { this.collateralRank = collateralRank; }
    public boolean isFirstDegreeInternal() { return isFirstDegreeInternal; }
    public void setFirstDegreeInternal(boolean firstDegreeInternal) { isFirstDegreeInternal = firstDegreeInternal; }
    public String getFirstDegreeCollateralId() { return firstDegreeCollateralId; }
    public void setFirstDegreeCollateralId(String firstDegreeCollateralId) { this.firstDegreeCollateralId = firstDegreeCollateralId; }
    public String getFirstDegreeHolderName() { return firstDegreeHolderName; }
    public void setFirstDegreeHolderName(String firstDegreeHolderName) { this.firstDegreeHolderName = firstDegreeHolderName; }
    public String getFirstDegreeFacilityRef() { return firstDegreeFacilityRef; }
    public void setFirstDegreeFacilityRef(String firstDegreeFacilityRef) { this.firstDegreeFacilityRef = firstDegreeFacilityRef; }
    public double getFirstDegreeOutstandingBalance() { return firstDegreeOutstandingBalance; }
    public void setFirstDegreeOutstandingBalance(double firstDegreeOutstandingBalance) { this.firstDegreeOutstandingBalance = firstDegreeOutstandingBalance; }
    public String getFirstDegreeBalanceAsOfDate() { return firstDegreeBalanceAsOfDate; }
    public void setFirstDegreeBalanceAsOfDate(String firstDegreeBalanceAsOfDate) { this.firstDegreeBalanceAsOfDate = firstDegreeBalanceAsOfDate; }
    public double getRegisteredMortgageAmount() { return registeredMortgageAmount; }
    public void setRegisteredMortgageAmount(double registeredMortgageAmount) { this.registeredMortgageAmount = registeredMortgageAmount; }
    public String getMortgageRegistrationNumber() { return mortgageRegistrationNumber; }
    public void setMortgageRegistrationNumber(String mortgageRegistrationNumber) { this.mortgageRegistrationNumber = mortgageRegistrationNumber; }
    public String getMortgageRegistrationDate() { return mortgageRegistrationDate; }
    public void setMortgageRegistrationDate(String mortgageRegistrationDate) { this.mortgageRegistrationDate = mortgageRegistrationDate; }
    public String getFirstDegreePolicyNumber() { return firstDegreePolicyNumber; }
    public void setFirstDegreePolicyNumber(String firstDegreePolicyNumber) { this.firstDegreePolicyNumber = firstDegreePolicyNumber; }
    public String getFirstDegreeInsurer() { return firstDegreeInsurer; }
    public void setFirstDegreeInsurer(String firstDegreeInsurer) { this.firstDegreeInsurer = firstDegreeInsurer; }
    public String getFirstDegreePolicyExpiry() { return firstDegreePolicyExpiry; }
    public void setFirstDegreePolicyExpiry(String firstDegreePolicyExpiry) { this.firstDegreePolicyExpiry = firstDegreePolicyExpiry; }
    public boolean isBankNotedAsSecondMortgagee() { return bankNotedAsSecondMortgagee; }
    public void setBankNotedAsSecondMortgagee(boolean bankNotedAsSecondMortgagee) { this.bankNotedAsSecondMortgagee = bankNotedAsSecondMortgagee; }
    public String getFirstDegreeConfirmationDocId() { return firstDegreeConfirmationDocId; }
    public void setFirstDegreeConfirmationDocId(String firstDegreeConfirmationDocId) { this.firstDegreeConfirmationDocId = firstDegreeConfirmationDocId; }
    public String getFirstDegreeExtractDocId() { return firstDegreeExtractDocId; }
    public void setFirstDegreeExtractDocId(String firstDegreeExtractDocId) { this.firstDegreeExtractDocId = firstDegreeExtractDocId; }
    public String getBorrowerCustomerId() { return borrowerCustomerId != null ? borrowerCustomerId : customerId; }
    public void setBorrowerCustomerId(String borrowerCustomerId) { this.borrowerCustomerId = borrowerCustomerId; }
    public String getLegalOwnerCustomerId() { return legalOwnerCustomerId; }
    public void setLegalOwnerCustomerId(String legalOwnerCustomerId) { this.legalOwnerCustomerId = legalOwnerCustomerId; }
    public String getLegalOwnerName() { return legalOwnerName; }
    public void setLegalOwnerName(String legalOwnerName) { this.legalOwnerName = legalOwnerName; }
    public boolean isOwnerWithoutCif() { return ownerWithoutCif; }
    public void setOwnerWithoutCif(boolean ownerWithoutCif) { this.ownerWithoutCif = ownerWithoutCif; }

    public String getRelationshipContext() {
        if (relationshipContext != null && !relationshipContext.isBlank()) return relationshipContext;
        return isThirdParty() ? "Third-party" : "Borrower-owned";
    }
    public void setRelationshipContext(String relationshipContext) { this.relationshipContext = relationshipContext; }
    public boolean isThirdParty() { return thirdParty; }
    public void setThirdParty(boolean thirdParty) { this.thirdParty = thirdParty; }
    public String getRelationshipToBorrower() { return relationshipToBorrower; }
    public void setRelationshipToBorrower(String relationshipToBorrower) { this.relationshipToBorrower = relationshipToBorrower; }
    public String getPledgeAgreementRef() { return pledgeAgreementRef; }
    public void setPledgeAgreementRef(String pledgeAgreementRef) { this.pledgeAgreementRef = pledgeAgreementRef; }
    public String getConsentInfo() { return consentInfo; }
    public void setConsentInfo(String consentInfo) { this.consentInfo = consentInfo; }
    public String getConsentDocumentRef() { return consentDocumentRef; }
    public void setConsentDocumentRef(String consentDocumentRef) { this.consentDocumentRef = consentDocumentRef; }

    public boolean isEffectiveActive() {
        String stat = this.status != null ? this.status : this.relationshipStatus;
        if (stat == null) return false;
        if (!"Active".equalsIgnoreCase(stat) && !"Approved".equalsIgnoreCase(stat)) {
            return false;
        }
        if ("Released".equalsIgnoreCase(stat) || "Historical".equalsIgnoreCase(stat) || "Ended".equalsIgnoreCase(stat)
                || "Cancelled".equalsIgnoreCase(stat) || "Rejected".equalsIgnoreCase(stat) || "Draft".equalsIgnoreCase(stat)
                || "Pending Approval".equalsIgnoreCase(stat)) {
            return false;
        }
        if (this.authStat != null && !"A".equalsIgnoreCase(this.authStat)) {
            return false;
        }
        if (this.endDate != null && !this.endDate.isBlank()) {
            try {
                java.time.LocalDate end = java.time.LocalDate.parse(this.endDate.substring(0, 10));
                if (end.isBefore(java.time.LocalDate.now())) {
                    return false;
                }
            } catch (Exception ignored) {}
        }
        return true;
    }

    public boolean isCapacityConsuming() {
        String stat = this.status != null ? this.status : this.relationshipStatus;
        if (stat == null) return false;
        if ("Released".equalsIgnoreCase(stat) || "Historical".equalsIgnoreCase(stat) || "Ended".equalsIgnoreCase(stat)
                || "Cancelled".equalsIgnoreCase(stat) || "Rejected".equalsIgnoreCase(stat)) {
            return false;
        }
        return "Active".equalsIgnoreCase(stat) || "Pending Approval".equalsIgnoreCase(stat) || "Draft".equalsIgnoreCase(stat);
    }
}
