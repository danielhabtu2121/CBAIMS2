package com.bank.cims.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {
    @Autowired private AdminAuthorizationInterceptor adminAuthorizationInterceptor;
    @Autowired private SecurityAuthenticationInterceptor securityAuthenticationInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(securityAuthenticationInterceptor);
        registry.addInterceptor(adminAuthorizationInterceptor);
    }
}
